# Matriz de requisitos — versão acadêmica

Base: Interface.txt, descrição Soberbrain e diretrizes do TCC, especialmente itens 4.1–4.6 e 6. O escopo detalhado foi consolidado para esta reconstrução e não substitui a lista de requisitos aprovada pelo professor.

| ID | Requisito | Situação / evidência |
|---|---|---|
| RF01 | Criar conta, entrar, sair | API cadastro/login/sair, perfil |
| RF02 | Registrar humor em cinco níveis | Início, Diário, check-in |
| RF03 | Registrar uso, ausência, vontade, substância e quantidade opcional | Diário / registros: múltiplas substâncias e detalhes independentes |
| RF04 | Registrar múltiplas atividades, contexto, reflexão, sono, energia e estresse | Diário |
| RF05 | Consultar, alterar e excluir registros próprios | GET/PUT/DELETE registros |
| RF06 | Calendário e histórico diário | Evolução |
| RF07 | Estatísticas básicas por mês | Evolução: humores e frequência de uso |
| RF08 | Criar, consultar, renomear e excluir metas | Metas / API |
| RF09 | Catálogo de substâncias e metas independentes | substancias / metas |
| RF10 | Cinco marcos e contador após conclusão | progresso.js / metas.js |
| RF11 | Meta de redução e bem-estar | progresso.js |
| RF12 | Histórico de conquistas após novo consumo | conquistas / observe() |
| RF13 | Atualizar perfil, exportar e excluir dados | perfil / exportar |
| RF14 | Acesso como visitante com exemplos isolados | demo |
| RF15 | Módulo complementar integrado | check-in rápido, mesma API e banco |
| RF16 | Boas-vindas e questionário inicial opcional | Escolha de interesse sem armazenamento; direcionamento para Diário ou Metas |
| RF17 | Notificações opcionais e troca de tema | Pendentes desde a versão anterior |
| RNF01 | Interface semântica e responsiva | HTML/CSS, menus desktop/móvel; validação visual pendente |
| RNF02 | Acessibilidade básica | labels, foco, aria, redução de movimento; auditoria pendente |
| RNF03 | Privacidade e autorização | sessão e filtro por usuário; banco não criptografado |
| RNF04 | Validação e tratamento de erros | API, formulários e retornos genéricos |
| RNF05 | Proteção de senha e SQL parametrizado | auth.js e db.prepare |
| RNF06 | Manutenibilidade | arquivos por responsabilidade e testes |
| RNF07 | Banco relacional normalizado com chaves | schema.sql, oito tabelas |
| RNF08 | Versionamento e documentação | estrutura + README; commits e GitHub a cargo da equipe |
| RNF09 | Identidade visual e transições suaves | assets PNG e SVG, CSS; validação visual pendente |

## Testes

`npm test` — oito testes unitários + um teste de integração HTTP e um teste de persistência. Cobertura: datas civis, marcos, conclusão, substâncias independentes, ausência de registros, redução, bem-estar, cadastro, criação/edição/exclusão, isolamento entre contas, nova ocorrência após uma conquista. Não é uma auditoria exaustiva. Na revisão 3.0 os oito testes de progresso passaram e a sintaxe dos scripts foi verificada. O acesso ao registro npm falhou por DNS, impedindo executar a integração/persistência com sql.js nesta revisão. O navegador também bloqueou localhost; verificar visualmente a aplicação após instalação.

## Atualização 3.1

RF18: selecionar múltiplas substâncias e atividades no mesmo registro, consultar, editar e excluir o conjunto; RF19: registrar sono, energia, estresse e detalhes opcionais por substância; RF20: pesquisar catálogo e filtrar histórico por data. RNF10: gravação atômica e compatibilidade com registros legados. As metas usam projeção por substância/atividade, sem duplicar registros no histórico. O teste adicional cobre CRUD, validação, isolamento e metas independentes; os três testes integrados passaram com adaptador temporário SQLite nativo (não sql.js). Ver ATUALIZACAO-DIARIO.md.

## DER (Mermaid)

```mermaid
erDiagram
 USUARIOS ||--o{ REGISTROS : possui
 USUARIOS ||--o{ METAS : define
 SUBSTANCIAS o|--o{ REGISTROS : classifica
 SUBSTANCIAS o|--o{ METAS : classifica
 METAS ||--o{ CONQUISTAS : gera
 REGISTROS ||--o| DIARIO_DETALHES : detalha
 REGISTROS ||--o{ DIARIO_ATIVIDADES : inclui
 REGISTROS ||--o{ DIARIO_SUBSTANCIAS : inclui
 SUBSTANCIAS ||--o{ DIARIO_SUBSTANCIAS : identifica
 DIARIO_DETALHES { int registro_id PK,FK
 float sono
 int energia
 int estresse }
 DIARIO_ATIVIDADES { int registro_id PK,FK
 string atividade PK }
 DIARIO_SUBSTANCIAS { int registro_id PK,FK
 int substancia_id PK,FK
 string consumo
 string quantidade
 string horario
 string contexto
 int vontade }
 USUARIOS { int id PK
 string nome
 string email UK
 string senha }
 SUBSTANCIAS { int id PK
 string nome UK
 string categoria }
 REGISTROS { int id PK
 int usuario_id FK
 int substancia_id FK
 date data
 int humor
 string atividade
 string consumo
 string quantidade
 string nota }
 METAS { int id PK
 int usuario_id FK
 int substancia_id FK
 string titulo
 string tipo
 date inicio
 int dias
 int limite
 string atividade }
 CONQUISTAS { int id PK
 int meta_id FK
 date ciclo
 date data }
```

Arquitetura: Navegador HTML/CSS/JS → HTTP JSON (Node.js) → SQLite. O cálculo ocorre no servidor e a interface apenas apresenta seu resultado. A consulta de Metas registra conquistas idempotentemente (chave única meta/ciclo). O front-end complementar reutiliza os endpoints.
