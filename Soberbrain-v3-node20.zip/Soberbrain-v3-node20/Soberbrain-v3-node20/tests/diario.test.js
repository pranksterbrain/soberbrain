const test = require('node:test');
const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const { mkdtempSync, rmSync } = require('node:fs');
const { tmpdir } = require('node:os');
const { join } = require('node:path');
const { today, add } = require('../backend/services/progresso');

test('Diário múltiplo: CRUD, validação, metas independentes e privacidade', async () => {
    const dir = mkdtempSync(join(tmpdir(),'sober-diary-'));
    const port = 39282;
    const child = spawn(process.execPath,['backend/server.js'], {env:{...process.env, PORT:String(port), SOBER_DB:join(dir,'test.sqlite')},stdio:['ignore','pipe','pipe']});
    try {
        await new Promise((resolve,reject)=>{
            const timeout=setTimeout(()=>reject(Error('Servidor não iniciou')),6000);
            child.once('error',e=>{clearTimeout(timeout);reject(e);});
            child.once('exit',code=>{clearTimeout(timeout);reject(Error('Servidor encerrou: '+code));});
            child.stdout.on('data',d=>{if(String(d).includes('Soberbrain:')){clearTimeout(timeout);resolve();}});
        });
        async function call(path,method='GET',body,cookie){
            const r=await fetch(`http://127.0.0.1:${port}/api/${path}`,{method,headers:{'Content-Type':'application/json',...(cookie?{Cookie:cookie}:{})},...(body!==undefined?{body:JSON.stringify(body)}:{})});
            return {status:r.status,data:await r.json(),cookie:r.headers.get('set-cookie')?.split(';')[0]};
        }
        const a=await call('cadastro','POST',{nome:'Teste A',email:'diario-a@local.invalid',senha:'testesenha'});
        const b=await call('cadastro','POST',{nome:'Teste B',email:'diario-b@local.invalid',senha:'testesenha'});
        assert.equal(a.status,200); assert.equal(b.status,200);
        const c=a.cookie, cat=(await call('substancias','GET',undefined,c)).data;
        const one=cat[0].id,two=cat[1].id;
        for(const sid of [one,two]) assert.equal((await call('metas','POST',{titulo:'Teste',tipo:'abstinencia',substancia_id:sid,inicio:add(today(),-8),dias:7},c)).status,200);
        assert.equal((await call('metas','POST',{titulo:'Exercício',tipo:'bemestar',atividade:'Exercício',inicio:today(),dias:7,limite:1},c)).status,200);
        assert.equal((await call('metas','POST',{titulo:'Estudo',tipo:'bemestar',atividade:'Estudo',inicio:today(),dias:7,limite:1},c)).status,200);
        const entry={data:today(),humor:2,atividades:['Estudo','Exercício'],substancias:[{substancia_id:one,consumo:'uso',quantidade:'fictícia',horario:'12:00',contexto:'teste',vontade:3},{substancia_id:two,consumo:'sem_uso'}],sono:7.5,energia:4,estresse:2,nota:'Teste fictício'};
        assert.equal((await call('registros','POST',{...entry,substancias:[entry.substancias[0],entry.substancias[0]]},c)).status,400);
        assert.equal((await call('registros','POST',{...entry,sono:25},c)).status,400);
        assert.equal((await call('registros','POST',{...entry,atividades:['inventada']},c)).status,400);
        assert.equal((await call('registros','GET',undefined,c)).data.length,0);
        const created=await call('registros','POST',entry,c);assert.equal(created.status,200);
        const id=created.data.id;
        let list=(await call('registros','GET',undefined,c)).data;
        assert.equal(list.length,1);assert.equal(list[0].substancias.length,2);assert.equal(list[0].atividades.length,2);assert.equal(list[0].sono,7.5);assert.equal(list[0].humor,2);
        let goals=(await call('metas','GET',undefined,c)).data;
        assert.equal(goals.find(g=>g.substancia_id===one).progresso.value,0);
        assert.equal(goals.find(g=>g.substancia_id===two).progresso.value,8);
        assert.ok(goals.filter(g=>g.tipo==='bemestar').every(g=>g.progresso.complete));
        assert.equal((await call('registros','GET',undefined,b.cookie)).data.length,0);
        assert.equal((await call(`registros/${id}`,'PUT',entry,b.cookie)).status,404);
        assert.equal((await call(`registros/${id}`,'DELETE',undefined,b.cookie)).status,404);
        assert.equal((await call(`registros/${id}`,'PUT',{...entry,atividades:['Estudo'],substancias:[{substancia_id:two,consumo:'uso'}]},c)).status,200);
        list=(await call('registros','GET',undefined,c)).data;
        assert.equal(list.length,1);assert.equal(list[0].substancias.length,1);assert.equal(list[0].atividades.length,1);
        assert.equal((await call('exportar','GET',undefined,c)).data.registros[0].substancias[0].substancia_id,two);
        assert.equal((await call(`registros/${id}`,'DELETE',undefined,c)).status,200);
        assert.equal((await call('registros','GET',undefined,c)).data.length,0);
        assert.equal((await call('registros','POST',{data:today(),humor:1,atividade:'Estudo',substancia_id:one,consumo:'vontade'},c)).status,200);
        list=(await call('registros','GET',undefined,c)).data;
        assert.equal(list[0].substancias.length,1);assert.deepEqual(list[0].atividades,['Estudo']);
        assert.equal((await call(`registros/${list[0].id}`,'PUT',entry,c)).status,200);
        assert.equal((await call('registros','GET',undefined,c)).data[0].substancias.length,2);
    } finally {if(child.exitCode===null){child.kill();await new Promise(r=>child.once('exit',r));}rmSync(dir,{recursive:true,force:true});}
});
