const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');

test('SQLite: persistência entre processos e exclusão em cascata', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'sober-db-'));
  const filename = path.join(dir, 'test.sqlite');
  const env = { ...process.env, SOBER_DB: filename };
  const execute = code => {
    const result = spawnSync(process.execPath, ['-e', `const db=require('./backend/services/db'); (async()=>{await db.init(); ${code}})().catch(e=>{console.error(e);process.exitCode=1;});`], {env, encoding:'utf8'});
    assert.equal(result.status, 0, result.stderr);
  };
  try {
    execute(`const u=db.prepare('INSERT INTO usuarios(nome,email,senha) VALUES(?,?,?)').run('Teste','teste@local.invalid','ficticia').lastInsertRowid; db.prepare('INSERT INTO metas(usuario_id,titulo,tipo,inicio,dias,atividade) VALUES(?,?,?,?,?,?)').run(u,'Teste','bemestar','2026-01-01',7,'humor');`);
    assert.equal(fs.readFileSync(filename).subarray(0,16).toString(), 'SQLite format 3\0');
    execute(`const assert=require('node:assert/strict'); const u=db.prepare('SELECT id FROM usuarios WHERE email=?').get('teste@local.invalid'); assert.equal(db.prepare('SELECT * FROM metas WHERE usuario_id=?').all(u.id).length,1); db.prepare('DELETE FROM usuarios WHERE id=?').run(u.id); assert.equal(db.prepare('SELECT * FROM metas').all().length,0);`);
    execute(`const assert=require('node:assert/strict'); assert.equal(db.prepare('SELECT * FROM usuarios').all().length,0); assert.equal(db.prepare('SELECT * FROM metas').all().length,0);`);
  } finally { fs.rmSync(dir,{recursive:true,force:true}); }
});
