# Soberbrain 3.1 — Diário ampliado

Atualização destinada ao Soberbrain 3.0 compatível com Node.js 20.11.1. Não exige nova biblioteca.

## Instalação da atualização parcial
1. Pare o servidor (`Ctrl+C`) e faça backup da pasta do projeto e de `database/soberbrain.sqlite`, se existir.
2. Extraia o ZIP de atualização e copie seu conteúdo para a pasta que contém `package.json`, mantendo os diretórios. Aceite substituir os arquivos listados. Não substitua nem exclua `soberbrain.sqlite`.
3. Os arquivos CSS anteriores, incluindo `geral.css`, `metas.css` e `home.css`, não são substituídos pela atualização parcial. O novo `diario.css` já é importado pelo novo HTML.
4. Execute `npm.cmd start`. Se ainda não instalou as dependências, execute antes `npm.cmd install --no-audit --no-fund`. Atualize o navegador com `Ctrl+F5`.
5. O script SQL é aplicado ao iniciar: cria três novas tabelas sem apagar as cinco originais. Registros antigos continuam legíveis e passam ao formato ampliado quando editados no novo Diário. A aplicação anterior não compreende os novos detalhes; não use as duas versões simultaneamente nem faça downgrade sem restaurar backup.

## Arquivos alterados
- `frontend/pages/diario.html`: quatro seções, formulário e histórico.
- `frontend/css/pages/diario.css`: estilos exclusivos do Diário.
- `frontend/js/pages/diario.js`: seleção múltipla, pesquisa, CRUD.
- `frontend/js/pages/calendario.js`: compatível com a reformulação de cores e ícones enviada anteriormente; mostra todas as substâncias e atividades.
- `backend/services/diario.js`: modelo ampliado, listagem, projeção de registros para metas.
- `backend/routes/api.js`: validação de novos campos e integração com metas, exportação e rotas antigas.
- `backend/services/db.js`: transação atômica para salvar todos os dados de um registro.
- `database/schema.sql`: três novas tabelas relacionadas, sem `DROP` ou remoção de registros.
- `tests/diario.test.js`, `package.json`: teste de integração e versão.
- `docs/requisitos.md`: requisitos e DER atualizados.

## Modelo e decisões
Um registro pode conter até 33 substâncias diferentes (uma ocorrência agregada por substância por registro), 22 opções de atividades/contexto, um humor, reflexão, sono em horas, energia e estresse de 1 a 5. Cada substância tem estado independente, quantidade e horário aproximado opcionais (apenas para consumo), intensidade de vontade e contexto. Não há sugestões de dose nem análises clínicas. Para registrar eventos diferentes da mesma substância, crie registros separados. Os registros antigos continuam usando as colunas legadas; os novos usam tabelas relacionadas. O estado de consumo precisa ser explicitamente escolhido para cada substância adicionada; ausência de registro não significa ausência de consumo. Atividades antigas continuam reconhecidas pelas metas de bem-estar; as novas opções servem ao acompanhamento no Diário. As metas de substâncias consideram todas as substâncias registradas. O Calendário conta cada entrada uma vez e a frequência de consumo por dias distintos e substância. A exportação contém os campos ampliados.

## Validação e limites
Os oito testes originais de progresso passaram com Node local. Os três testes de integração/persistência passaram com um adaptador temporário de SQLite nativo (Node 22), não incluído nesta entrega. O download de sql.js foi bloqueado por DNS, portanto execute `npm.cmd test` no computador de destino para confirmar o driver real com Node 20. O navegador recusou localhost por política administrativa; a validação visual e de interação manual permanece pendente. O select mantém o menu nativo do navegador, com aparência fechada estilizada, pesquisa e categorias. O aplicativo é acadêmico: não utilize dados reais de saúde em computadores compartilhados; o SQLite não é criptografado em repouso.
