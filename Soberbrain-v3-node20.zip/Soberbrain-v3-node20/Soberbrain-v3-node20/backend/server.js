const http=require('node:http'),fs=require('node:fs'),path=require('node:path');
async function start(){
 await require('./services/db').init();
 const api=require('./routes/api');
const root=path.resolve(__dirname,'../frontend');const mime={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.svg':'image/svg+xml','.png':'image/png'};
const attempts=new Map();
http.createServer(async(req,res)=>{res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');res.setHeader('Content-Security-Policy',"default-src 'self'; style-src 'self'; script-src 'self'; img-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");res.setHeader('Cache-Control','no-store');
 try{const url=new URL(req.url,'http://localhost'),p=decodeURIComponent(url.pathname);if(p.startsWith('/api/')){res.setHeader('Content-Type','application/json; charset=utf-8');if(!['GET','POST','PUT','DELETE'].includes(req.method))throw Object.assign(new Error('Método inválido.'),{status:405});let body={};if(req.method!=='GET'){if(req.headers.origin&&new URL(req.headers.origin).host!==req.headers.host)throw Object.assign(new Error('Origem inválida.'),{status:403});let raw='';for await(const chunk of req){raw+=chunk;if(raw.length>24000)throw Object.assign(new Error('Dados muito extensos.'),{status:413});}if(raw){try{body=JSON.parse(raw);if(!body||typeof body!=='object'||Array.isArray(body))throw Error();}catch{throw Object.assign(new Error('JSON inválido.'),{status:400});}}if(['/api/login','/api/cadastro','/api/demo'].includes(p)){const k=req.socket.remoteAddress,now=Date.now(),a=attempts.get(k)||{n:0,t:now};if(now-a.t>60000){a.n=0;a.t=now;}a.n++;attempts.set(k,a);if(a.n>20)throw Object.assign(new Error('Muitas tentativas. Tente novamente em um minuto.'),{status:429});}}
 const data=await api(req,res,p,body);res.end(JSON.stringify(data));return;}
 const file=path.resolve(root,'.'+(p==='/'?'/index.html':p));if(!file.startsWith(root+path.sep)||!mime[path.extname(file)]||!fs.existsSync(file)||!fs.statSync(file).isFile()){res.writeHead(404);res.end('Página não encontrada');return;}res.setHeader('Content-Type',mime[path.extname(file)]);res.end(fs.readFileSync(file));
 }catch(e){if(!e.status)console.error(e.message);res.statusCode=e.status||500;res.setHeader('Content-Type','application/json; charset=utf-8');res.end(JSON.stringify({erro:e.status?e.message:'Não foi possível concluir a operação.'}));}
}).listen(Number(process.env.PORT||3000),process.env.HOST||'127.0.0.1',()=>console.log('Soberbrain: http://localhost:'+(process.env.PORT||3000)));

}
start().catch(error=>{console.error("Falha ao iniciar o Soberbrain:",error.message);process.exitCode=1;});
