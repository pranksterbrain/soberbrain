const diario=require('../services/diario');
const db=require('../services/db');const auth=require('../services/auth');const {today,add,diff,progress}=require('../services/progresso');
const {randomBytes}=require('node:crypto');
const all=(sql,...p)=>db.prepare(sql).all(...p);const get=(sql,...p)=>db.prepare(sql).get(...p);const run=(sql,...p)=>db.prepare(sql).run(...p);
function fail(message,status=400){throw Object.assign(new Error(message),{status});}
function text(v,max,required=false){if(typeof v!=='string'||v.trim().length>max||(required&&!v.trim()))fail('Revise os campos informados.');return v.trim();}
function integer(v,min,max){if(!Number.isInteger(v)||v<min||v>max)fail('Valor numérico inválido.');return v;}
function date(v){if(typeof v!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(v)||!Number.isFinite(Date.parse(v))||new Date(v).toISOString().slice(0,10)!==v||v>today()||v<'1900-01-01')fail('Informe uma data válida, não futura.');return v;}
function substance(v){const n=integer(v,1,1000000);if(!get('SELECT id FROM substancias WHERE id=?',n))fail('Substância inválida.');return n;}
const activities=['humor','Exercício','Estudo','Trabalho','Descanso','Lazer','Social','Ansiedade','Conflito'];
function activity(v){if(!activities.includes(v))fail('Atividade inválida.');return v;}
function goals(id){const records=diario.progressRows(id);return all('SELECT m.*,s.nome AS substancia FROM metas m LEFT JOIN substancias s ON s.id=m.substancia_id WHERE m.usuario_id=? ORDER BY m.id DESC',id).map(m=>({...m,progresso:progress(m,records),conquistas:all('SELECT ciclo,data FROM conquistas WHERE meta_id=? ORDER BY data DESC',m.id)}));}
function observe(id){
 for(const m of goals(id)){
  // Recupera sequências anteriores, mesmo se a página não foi aberta antes do próximo uso.
  if(m.tipo==='abstinencia'){
   const uses=[...new Set(diario.progressRows(id).filter(r=>r.substancia_id===m.substancia_id&&r.consumo==='uso'&&r.data>=m.inicio&&r.data<=today()).map(r=>r.data))].sort().map(data=>({data}));let anchor=m.inicio;
   for(const {data} of uses){if(diff(anchor,data)>m.dias)run('INSERT OR IGNORE INTO conquistas(meta_id,ciclo,data) VALUES(?,?,?)',m.id,anchor,add(anchor,m.dias));anchor=data;}
  }
  if(m.progresso.complete)run('INSERT OR IGNORE INTO conquistas(meta_id,ciclo,data) VALUES(?,?,?)',m.id,m.progresso.cycle,today());
 }
 return goals(id);
}
async function api(req,res,path,body){const method=req.method;const id=auth.user(req);let m;
 if(path==='/api/cadastro'&&method==='POST'){const nome=text(body.nome,60,true),email=text(body.email,120,true).toLowerCase(),senha=text(body.senha,128,true);if(!/^\S+@\S+\.\S+$/.test(email)||senha.length<8)fail('E-mail válido e senha com ao menos 8 caracteres.');if(get('SELECT id FROM usuarios WHERE email=?',email))fail('Não foi possível criar a conta.',409);const r=run('INSERT INTO usuarios(nome,email,senha) VALUES(?,?,?)',nome,email,auth.hash(senha));auth.login(req,res,Number(r.lastInsertRowid));return {ok:true};}
 if(path==='/api/login'&&method==='POST'){const email=text(body.email,120,true).toLowerCase(),senha=text(body.senha,128,true);const u=get('SELECT * FROM usuarios WHERE email=?',email);if(!u||!auth.check(senha,u.senha))fail('Credenciais inválidas.',401);auth.login(req,res,u.id);return {ok:true};}
 if(path==='/api/demo'&&method==='POST'){const r=run('INSERT INTO usuarios(nome,email,senha) VALUES(?,?,?)','Visitante','demo-'+randomBytes(12).toString('hex')+'@local.invalid',auth.hash(randomBytes(24).toString('hex')));const uid=Number(r.lastInsertRowid),s=get("SELECT id FROM substancias WHERE nome='Cannabis'").id;run('INSERT INTO metas(usuario_id,titulo,tipo,substancia_id,inicio,dias) VALUES(?,?,?,?,?,?)',uid,'Meu primeiro passo','abstinencia',s,add(today(),-12),30);run('INSERT INTO metas(usuario_id,titulo,tipo,substancia_id,inicio,dias) VALUES(?,?,?,?,?,?)',uid,'Mais espaço para mim','abstinencia',get("SELECT id FROM substancias WHERE nome='Nicotina'").id,add(today(),-35),30);auth.login(req,res,uid);return {ok:true};}
 if(!id)fail('Entre na sua conta.',401);
 if(path==='/api/sair'&&method==='POST'){auth.logout(req,res);return {ok:true};}
 if(path==='/api/perfil'&&method==='GET')return get('SELECT id,nome,email FROM usuarios WHERE id=?',id);
 if(path==='/api/perfil'&&method==='PUT'){run('UPDATE usuarios SET nome=? WHERE id=?',text(body.nome,60,true),id);return {ok:true};}
 if(path==='/api/perfil'&&method==='DELETE'){run('DELETE FROM usuarios WHERE id=?',id);auth.revoke(id);auth.logout(req,res);return {ok:true};}
 if(path==='/api/substancias'&&method==='GET')return all('SELECT * FROM substancias ORDER BY categoria,nome');
 if(path==='/api/metas'&&method==='GET')return observe(id);
 if(path==='/api/registros'&&method==='GET')return diario.list(id);
 if(path==='/api/estado'&&method==='GET')return {usuario:get('SELECT nome FROM usuarios WHERE id=?',id),metas:goals(id),registros:diario.list(id),hoje:today()};
 if(path==='/api/exportar'&&method==='GET')return {perfil:get('SELECT nome,email FROM usuarios WHERE id=?',id),metas:goals(id),registros:diario.list(id)};
 if(path==='/api/metas'&&method==='POST'||(m=path.match(/^\/api\/metas\/(\d+)$/))&&method==='PUT'){
  const titulo=text(body.titulo,80,true),tipo=body.tipo;if(!['abstinencia','reducao','bemestar'].includes(tipo))fail('Tipo inválido.');const inicio=date(body.inicio),dias=integer(body.dias,1,3650),sid=tipo==='bemestar'?null:substance(body.substancia_id),limite=tipo==='abstinencia'?0:integer(body.limite,tipo==='reducao'?0:1,dias),at=tipo==='bemestar'?activity(body.atividade):null;
  if(m){const old=get('SELECT * FROM metas WHERE id=? AND usuario_id=?',+m[1],id);if(!old)fail('Meta não encontrada.',404);if(old.tipo!==tipo||old.substancia_id!==sid||old.inicio!==inicio||old.dias!==dias||old.limite!==limite||old.atividade!==at)fail('Para mudar as regras, crie outra meta. A edição altera apenas o título.');run('UPDATE metas SET titulo=? WHERE id=? AND usuario_id=?',titulo,+m[1],id);}else run('INSERT INTO metas(usuario_id,titulo,tipo,substancia_id,inicio,dias,limite,atividade) VALUES(?,?,?,?,?,?,?,?)',id,titulo,tipo,sid,inicio,dias,limite,at);return {ok:true};
 }
 if((m=path.match(/^\/api\/metas\/(\d+)$/))&&method==='DELETE'){if(!run('DELETE FROM metas WHERE id=? AND usuario_id=?',+m[1],id).changes)fail('Meta não encontrada.',404);return {ok:true};}
 if(path==='/api/registros'&&method==='POST'||(m=path.match(/^\/api\/registros\/(\d+)$/))&&method==='PUT'){
  if('substancias' in body||'atividades' in body||'sono' in body||'energia' in body||'estresse' in body){
   const data=date(body.data), humor=body.humor==null?null:integer(body.humor,1,5), nota=text(body.nota??'',2000);
   const atos=body.atividades??[], subs=body.substancias??[];
   if(!Array.isArray(atos)||atos.length>diario.activities.length||!Array.isArray(subs)||subs.length>33)fail('Revise as seleções.');
   const atividades=[...new Set(atos.map(a=>{if(!diario.activities.includes(a))fail('Atividade inválida.');return a;}))];
   const optionalLevel=v=>v==null?null:integer(v,1,5);
   const sono=body.sono??null;
   if(sono!==null&&(typeof sono!=='number'||!Number.isFinite(sono)||sono<0||sono>24))fail('Sono: informe de 0 a 24 horas.');
   const energia=optionalLevel(body.energia), estresse=optionalLevel(body.estresse);
   const seen=new Set();
   const substancias=subs.map(s=>{
    if(!s||typeof s!=='object'||Array.isArray(s))fail('Substância inválida.');
    const substancia_id=substance(s.substancia_id);
    if(seen.has(substancia_id))fail('Não repita a mesma substância no registro.');seen.add(substancia_id);
    const consumo=s.consumo;if(!['uso','sem_uso','vontade'].includes(consumo))fail('Informe o que aconteceu para cada substância.');
    const quantidade=consumo==='uso'?text(s.quantidade??'',60):'';
    const horario=consumo==='uso'?text(s.horario??'',5):'';
    if(horario&&!/^([01]\d|2[0-3]):[0-5]\d$/.test(horario))fail('Horário inválido.');
    return {substancia_id,consumo,quantidade,horario,contexto:text(s.contexto??'',160),vontade:optionalLevel(s.vontade)};
   });
   if(!humor&&!nota&&!atividades.length&&!substancias.length&&sono===null&&energia===null&&estresse===null)fail('Preencha ao menos uma informação.');
   return diario.save(id,m?+m[1]:null,{data,humor,nota,atividades,substancias,sono,energia,estresse});
  }
  if(m&&get('SELECT d.registro_id FROM diario_detalhes d JOIN registros r ON r.id=d.registro_id WHERE r.id=? AND r.usuario_id=?',+m[1],id))fail('Abra o Diário atualizado para editar este registro.',409);
  const data=date(body.data),humor=body.humor==null?null:integer(body.humor,1,5),at=body.atividade?activity(body.atividade):null,nota=text(body.nota||'',2000),sid=body.substancia_id==null?null:substance(body.substancia_id),consumo=sid?body.consumo:null;if(sid&&!['uso','sem_uso','vontade'].includes(consumo))fail('Selecione o registro de consumo.');const quantidade=sid&&consumo==='uso'?text(body.quantidade||'',60):'';if(!humor&&!at&&!nota&&!sid)fail('Preencha ao menos uma informação.');
  if(m){if(!run('UPDATE registros SET data=?,humor=?,atividade=?,nota=?,quantidade=?,substancia_id=?,consumo=? WHERE id=? AND usuario_id=?',data,humor,at,nota,quantidade,sid,consumo,+m[1],id).changes)fail('Registro não encontrado.',404);}else run('INSERT INTO registros(usuario_id,data,humor,atividade,nota,quantidade,substancia_id,consumo) VALUES(?,?,?,?,?,?,?,?)',id,data,humor,at,nota,quantidade,sid,consumo);return {ok:true};
 }
 if((m=path.match(/^\/api\/registros\/(\d+)$/))&&method==='DELETE'){if(!run('DELETE FROM registros WHERE id=? AND usuario_id=?',+m[1],id).changes)fail('Registro não encontrado.',404);return {ok:true};}
 fail('Rota não encontrada.',404);
}
module.exports=api;
