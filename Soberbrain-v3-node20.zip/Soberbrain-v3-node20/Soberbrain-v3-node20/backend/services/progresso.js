'use strict';
const DAY=86400000;
const dateNum=s=>Date.parse(s+'T00:00:00Z');
const diff=(a,b)=>Math.round((dateNum(b)-dateNum(a))/DAY);
const add=(s,n)=>new Date(dateNum(s)+n*DAY).toISOString().slice(0,10);
function today(){return new Intl.DateTimeFormat('sv-SE',{timeZone:'America/Sao_Paulo',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());}
function progress(m,records,now=today()){
 const elapsed=Math.max(0,diff(m.inicio,now));
 const relevant=records.filter(r=>r.data>=m.inicio&&r.data<=now);
 const end=add(m.inicio,m.dias-1);
 const window=relevant.filter(r=>r.data<=end);
 let anchor=m.inicio, value, target=m.dias, complete, failed=false, observed=0;
 if(m.tipo==='abstinencia'){
  const usage=relevant.filter(r=>r.substancia_id===m.substancia_id&&r.consumo==='uso').map(r=>r.data).sort();
  anchor=usage.at(-1)||m.inicio;
  value=Math.max(0,diff(anchor,now));
  observed=new Set(relevant.filter(r=>r.substancia_id===m.substancia_id&&r.consumo==='sem_uso'&&r.data>anchor).map(r=>r.data)).size;
  complete=value>=target;
 }else if(m.tipo==='reducao'){
  value=new Set(window.filter(r=>r.substancia_id===m.substancia_id&&r.consumo==='uso').map(r=>r.data)).size;
  observed=new Set(window.filter(r=>r.substancia_id===m.substancia_id&&['uso','sem_uso'].includes(r.consumo)).map(r=>r.data)).size;
  target=m.limite; complete=elapsed>=m.dias&&value<=target&&observed>=m.dias; failed=value>target;
 }else{
  value=new Set(window.filter(r=>m.atividade==='humor'?r.humor!=null:r.atividade===m.atividade).map(r=>r.data)).size;
  target=m.limite; complete=value>=target; failed=elapsed>=m.dias&&!complete;
 }
 const ratio=m.tipo==='abstinencia'?value/m.dias:m.tipo==='reducao'?Math.min(elapsed,m.dias)/m.dias:value/target;
 const milestones=Array.from({length:5},(_,i)=>Math.ceil((i+1)*m.dias/5));
 return {anchor,value,target,complete,failed,observed,elapsed,ratio:Math.max(0,Math.min(1,ratio)),milestones,cycle:m.tipo==='abstinencia'?anchor:m.inicio,end,days:value};
}
module.exports={today,add,diff,progress};
