const fs = require('node:fs');
const path = require('node:path');
const filename = process.env.SOBER_DB || path.join(__dirname, '../../database/soberbrain.sqlite');
let db;
let initialized;
let inTransaction = false;

// sql.js uses WebAssembly, so Node 20 needs neither a native addon nor a compiler.
async function init() {
  if (!initialized) initialized = open();
  return initialized;
}
async function open() {
  const initSqlJs = require('sql.js');
  const SQL = await initSqlJs({ locateFile: file => path.join(path.dirname(require.resolve('sql.js')), file) });
  db = new SQL.Database(fs.existsSync(filename) ? fs.readFileSync(filename) : undefined);
  db.run('PRAGMA foreign_keys=ON');
  db.run(fs.readFileSync(path.join(__dirname, '../../database/schema.sql'), 'utf8'));
  persist();
}
function persist() {
  // Export a real SQLite database; replace the previous snapshot only after writing.
  const bytes = db.export();
  // sql.js 1.13 resets connection PRAGMAs during export.
  db.run('PRAGMA foreign_keys=ON');
  fs.mkdirSync(path.dirname(filename), { recursive: true });
  const temp = filename + '.tmp';
  try {
    fs.writeFileSync(temp, Buffer.from(bytes));
    fs.renameSync(temp, filename);
  } catch (err) {
    // Stop accepting requests with an in-memory state that was not saved.
    db.close();
    db = undefined;
    try { fs.unlinkSync(temp); } catch {}
    throw err;
  }
}
function query(sql, params, first) {
  const stmt = db.prepare(sql);
  try {
    stmt.bind(params);
    if (first) return stmt.step() ? stmt.getAsObject() : undefined;
    const rows = [];
    while (stmt.step()) rows.push(stmt.getAsObject());
    return rows;
  } finally { stmt.free(); }
}
function prepare(sql) {
  if (!db) throw new Error('Banco indisponível. Reinicie o servidor.');
  return {
    all: (...params) => query(sql, params, false),
    get: (...params) => query(sql, params, true),
    run: (...params) => {
      db.run(sql, params);
      const changes = db.getRowsModified();
      const lastInsertRowid = query('SELECT last_insert_rowid() AS id', [], true).id;
      if (changes && !inTransaction) persist();
      return { changes, lastInsertRowid };
    }
  };
}
// All writes to a diary entry are committed and exported together.
function transaction(work) {
  if (!db || inTransaction) throw new Error('Transação indisponível.');
  db.run('BEGIN');
  inTransaction = true;
  let result;
  try {
    result = work();
    db.run('COMMIT');
  } catch (error) {
    db.run('ROLLBACK');
    throw error;
  } finally {
    inTransaction = false;
  }
  persist();
  return result;
}
module.exports = { init, prepare, transaction };
