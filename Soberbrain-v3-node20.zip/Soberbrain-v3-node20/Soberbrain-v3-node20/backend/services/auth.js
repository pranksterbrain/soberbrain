const {randomBytes,scryptSync,timingSafeEqual}=require('node:crypto');
const sessions=new Map();
function hash(pass){const salt=randomBytes(16).toString('hex');return salt+':'+scryptSync(pass,salt,64).toString('hex');}
function check(pass,stored){const [salt,key]=stored.split(':');return timingSafeEqual(Buffer.from(key,'hex'),scryptSync(pass,salt,64));}
function token(req){return (req.headers.cookie||'').match(/(?:^|;\s*)sb=([a-f0-9]+)(?:;|$)/)?.[1];}
function user(req){const s=sessions.get(token(req));return s&&s.exp>Date.now()?s.id:null;}
function login(req,res,id){sessions.delete(token(req));const t=randomBytes(32).toString('hex');sessions.set(t,{id,exp:Date.now()+86400000});res.setHeader('Set-Cookie',`sb=${t}; HttpOnly; SameSite=Strict; Path=/; Max-Age=86400${process.env.SOBER_SECURE==='1'?'; Secure':''}`);}
function logout(req,res){sessions.delete(token(req));res.setHeader('Set-Cookie','sb=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0');}
function revoke(id){for(const [t,s] of sessions)if(s.id===id)sessions.delete(t);}
module.exports={hash,check,user,login,logout,revoke};
