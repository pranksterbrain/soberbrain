const db = require('./db');
const all = (sql, ...params) => db.prepare(sql).all(...params);
const get = (sql, ...params) => db.prepare(sql).get(...params);
const run = (sql, ...params) => db.prepare(sql).run(...params);
const activities = ['Exercício', 'Estudo', 'Trabalho', 'Descanso', 'Lazer', 'Social', 'Ansiedade', 'Conflito', 'Sono', 'Alimentação', 'Autocuidado', 'Terapia', 'Meditação', 'Leitura', 'Música', 'Família', 'Amigos', 'Solidão', 'Tédio', 'Comemoração', 'Estresse', 'Dor'];

function list(user) {
    const rows = all('SELECT r.*, s.nome AS substancia FROM registros r LEFT JOIN substancias s ON s.id=r.substancia_id WHERE r.usuario_id=? ORDER BY r.data DESC,r.id DESC', user);
    const details = new Map(all('SELECT d.* FROM diario_detalhes d JOIN registros r ON r.id=d.registro_id WHERE r.usuario_id=?', user).map(d => [d.registro_id, d]));
    const group = rows => {
        const map = new Map();
        for (const row of rows) {
            if (!map.has(row.registro_id)) map.set(row.registro_id, []);
            map.get(row.registro_id).push(row);
        }
        return map;
    };
    const substances = group(all('SELECT d.*,s.nome AS substancia FROM diario_substancias d JOIN registros r ON r.id=d.registro_id JOIN substancias s ON s.id=d.substancia_id WHERE r.usuario_id=? ORDER BY d.substancia_id', user));
    const acts = group(all('SELECT a.* FROM diario_atividades a JOIN registros r ON r.id=a.registro_id WHERE r.usuario_id=? ORDER BY a.atividade', user));
    return rows.map(r => {
        const extended = details.has(r.id);
        const subs = extended ? (substances.get(r.id) || []) : r.substancia_id ? [{substancia_id:r.substancia_id, substancia:r.substancia, consumo:r.consumo, quantidade:r.quantidade, horario:'', contexto:'', vontade:null}] : [];
        const atividades = extended ? (acts.get(r.id) || []).map(a => a.atividade) : r.atividade ? [r.atividade] : [];
        const d = details.get(r.id) || {};
        // Keep legacy scalar properties for existing clients; arrays are authoritative.
        return {...r, substancia_id:subs[0]?.substancia_id ?? null, substancia:subs[0]?.substancia ?? null, consumo:subs[0]?.consumo ?? null, quantidade:subs[0]?.quantidade ?? '', atividade:atividades[0] ?? null, substancias:subs, atividades, sono:d.sono ?? null, energia:d.energia ?? null, estresse:d.estresse ?? null};
    });
}

function progressRows(user) {
    return list(user).flatMap(r => [
        {data:r.data, humor:r.humor, atividade:null, substancia_id:null, consumo:null},
        ...r.atividades.map(atividade => ({data:r.data, atividade, humor:null, substancia_id:null, consumo:null})),
        ...r.substancias.map(s => ({data:r.data, substancia_id:s.substancia_id, consumo:s.consumo, humor:null, atividade:null}))
    ]);
}

function save(user, id, entry) {
    return db.transaction(() => {
        if (id != null) {
            if (!get('SELECT id FROM registros WHERE id=? AND usuario_id=?', id,user)) throw Object.assign(new Error('Registro não encontrado.'), {status:404});
            run('UPDATE registros SET data=?,humor=?,nota=?,atividade=NULL,substancia_id=NULL,consumo=NULL,quantidade=\'\' WHERE id=? AND usuario_id=?',entry.data,entry.humor,entry.nota,id,user);
            run('DELETE FROM diario_detalhes WHERE registro_id=?',id);
            run('DELETE FROM diario_atividades WHERE registro_id=?',id);
            run('DELETE FROM diario_substancias WHERE registro_id=?',id);
        } else {
            id = run('INSERT INTO registros(usuario_id,data,humor,nota) VALUES(?,?,?,?)',user,entry.data,entry.humor,entry.nota).lastInsertRowid;
        }
        run('INSERT INTO diario_detalhes(registro_id,sono,energia,estresse) VALUES(?,?,?,?)',id,entry.sono,entry.energia,entry.estresse);
        for (const a of entry.atividades) run('INSERT INTO diario_atividades(registro_id,atividade) VALUES(?,?)',id,a);
        for (const s of entry.substancias) run('INSERT INTO diario_substancias(registro_id,substancia_id,consumo,quantidade,horario,contexto,vontade) VALUES(?,?,?,?,?,?,?)',id,s.substancia_id,s.consumo,s.quantidade,s.horario,s.contexto,s.vontade);
        return {ok:true,id};
    });
}
module.exports = {list,progressRows,save,activities};
