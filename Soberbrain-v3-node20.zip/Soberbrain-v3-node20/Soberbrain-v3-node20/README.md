# Soberbrain 3.0 — identidade visual renovada

Revisão visual do Soberbrain 2.0.1 para o TCC, baseada nos protótipos Home(3).png e Inicio.png. O back-end, o schema SQL, os serviços, as rotas e as regras de metas foram preservados sem alterações. Navegação horizontal, ilustrações PNG temáticas e nova tela de boas-vindas.

## Executar no Windows

1. Extraia o ZIP em uma pasta (não é necessário usar XAMPP ou htdocs).
2. Use o Node.js **20.11.1 ou superior** já instalado. Esta versão usa `sql.js` (SQLite via WebAssembly), sem módulos nativos, compilador ou instalação global.
3. Abra o terminal na pasta que contém `package.json`.
4. Execute `npm.cmd install --no-audit --no-fund` uma vez (precisa de acesso permitido ao registro npm). Depois execute `npm.cmd start` e abra **http://localhost:3000**. O banco `database/soberbrain.sqlite` é criado automaticamente.
5. Entre com uma conta fictícia ou clique em **Explorar demonstração** para ver duas metas de exemplo. Cada demonstração cria uma conta isolada, sem credencial recuperável: apague-a no perfil antes de sair se não quiser mantê-la. Para persistir uma conta entre sessões, cadastre e-mail e senha fictícios.
6. Para encerrar, pressione Ctrl+C. Para executar os testes: `npm.cmd test`. No Prompt de Comando, também funcionam `npm install`, `npm start` e `npm test`.

O banco SQLite é carregado em memória e salvo em arquivo a cada alteração. Execute apenas uma instância por arquivo de banco. Não execute versões simultaneamente usando o mesmo arquivo. Para preservar registros da 2.0.1, pare o servidor, faça backup e copie database/soberbrain.sqlite para o mesmo caminho na nova pasta (schema idêntico). A versão Node 20 não deve ser usada para publicação: utilize um runtime mantido em produção. Se a escola bloquear o npm, solicite autorização ao responsável de TI; o projeto não inclui o pacote externo.

O servidor escuta apenas em 127.0.0.1 por padrão. A porta pode ser alterada pela variável `PORT`. Não abra os HTML por duplo clique, nem por Live Server: dependem da API na mesma origem. Não coloque o banco SQLite no Git.

## Estrutura

```text
frontend/
  index.html                  # Início
  login.html
  pages/                      # Diário, Evolução, Metas, Perfil, Privacidade, Check-in, Boas-vindas
  css/core/                   # tokens, layout, responsividade
  css/components/             # formulários, botões, diálogos
  css/pages/                  # estilos por tela, metas.css dedicado
  js/core/                    # API, componentes e navegação
  js/pages/                   # comportamento de cada página
  assets/karen/               # sete ilustrações PNG com transparência
  assets/icons/               # expressões de humor e ícones
backend/
  server.js                   # servidor HTTP e proteção básica
  routes/api.js               # endpoints e validação
  services/                   # persistência, autenticação e progresso
 database/                   # schema.sql, SQLite gerado na execução
 tests/                      # testes unitários e integração HTTP
 docs/                       # requisitos e modelo relacional
```

## Metas

- A data inicial é o dia zero. Contagem por datas civis em America/Sao_Paulo, não blocos de 24 horas.
- Cinco pontos em `ceil(n * duração / 5)` para n=1..5; metas menores que 5 dias podem ter pontos com a mesma data. Ao abrir Metas depois de atingir o prazo, a linha é substituída por quatro unidades totais (dias, semanas completas, meses de calendário completos e anos completos). Também atualiza ao voltar o foco ou após 60 segundos enquanto a página estiver aberta.
- A data do último uso registrado da mesma substância, a partir do início da meta, passa a ser o dia zero. Desejo de consumir ou consumo de outra substância não reinicia. Se houver uso e ausência no mesmo dia, o uso prevalece para a sequência. A ausência de registro não comprova abstinência: o tempo é rotulado como sem consumo *relatado*, e os dias confirmados aparecem separadamente.
- As conquistas persistidas são históricas, inclusive após novo uso. Ciclos anteriores identificáveis pelos registros também são recuperados na consulta de Metas; uma correção retroativa recalcula a sequência atual, mas não apaga o histórico já registrado. Excluir a meta exclui suas conquistas, com confirmação; o Diário permanece.
- Redução: estabelece um limite de dias com uso em uma janela inclusiva de N dias. Conclusão após o fim da janela, se todos os dias foram explicitamente registrados e o limite não foi excedido. Dias duplicados contam uma vez. Sem registro suficiente o período fica encerrado, mas não concluído. Bem-estar conta dias distintos com humor/atividade no intervalo.
- O título pode ser alterado; para mudar regras, prazo ou substância, crie outra meta (preserva o significado das conquistas anteriores).
- Catálogo local de 33 substâncias agrupadas por categoria, sem instruções de uso. Inspirado no conceito de registro por substância de Journal/PsychonautWiki Journal, não é uma importação do catálogo nem inclui cálculos de dose ou interações.

## Segurança, limites e entrega

Aplicação acadêmica local para dados fictícios: consultas parametrizadas, validação do servidor, hash scrypt com sal, cookie HttpOnly/SameSite, verificação de origem, limite básico de tentativas, controles de acesso por usuário, exportação/exclusão. O SQLite não é criptografado em repouso; sessões são mantidas em memória e terminam ao reiniciar o servidor. Para publicar: HTTPS, cookies Secure, auditoria de segurança, backups protegidos, política real de privacidade, revisão de requisitos legais, acessibilidade e testes completos. Não há notificações automáticas nem troca de tema. A tela de boas-vindas oferece uma escolha opcional de interesse, que direciona ao Diário ou Metas sem armazenar respostas. Não é aconselhamento médico; não alterar medicação sem orientação profissional.

O módulo complementar `pages/checkin.html` integra os registros de humor à mesma API. A interface foi construída de modo responsivo com CSS e redução de movimento conforme preferência do usuário, porém a automação do navegador foi bloqueada no ambiente de criação; falta validação visual e navegação manual completa. As imagens PNG seguem a estética low-poly das referências. Os símbolos de humor, o logotipo e os ícones de benefícios foram recortados dos protótipos enviados. A mascote da Home usa o tablet em vez de fumar. Metas e Perfil têm poses próprias; privacidade e login reutilizam a ilustração temática mais próxima. As animações são transições CSS (não um rig 3D). Links sociais não foram criados porque não foram fornecidos endereços oficiais.

Nesta revisão, os oito testes unitários de progresso passaram. O download de sql.js foi bloqueado por falha DNS no ambiente e o Chromium recusou o localhost por política administrativa; os testes HTTP/persistência com sql.js e a validação visual final precisam ser repetidos no computador de destino.

Para a entrega da PROZ, acrescente identificação dos integrantes, documentação final, capturas reais do site em execução, revisão do DER, apresentação e histórico real de commits. Este pacote não altera nem publica um repositório GitHub.

© The Creks — Soberbrain.
