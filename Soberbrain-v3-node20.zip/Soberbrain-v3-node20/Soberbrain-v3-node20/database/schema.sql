PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS usuarios(id INTEGER PRIMARY KEY AUTOINCREMENT, nome TEXT NOT NULL, email TEXT UNIQUE NOT NULL, senha TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS substancias(id INTEGER PRIMARY KEY, nome TEXT UNIQUE NOT NULL, categoria TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS registros(id INTEGER PRIMARY KEY, usuario_id INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE, data TEXT NOT NULL, humor INTEGER CHECK(humor BETWEEN 1 AND 5), atividade TEXT, nota TEXT NOT NULL DEFAULT '', quantidade TEXT NOT NULL DEFAULT '', substancia_id INTEGER REFERENCES substancias(id), consumo TEXT CHECK(consumo IN ('uso','sem_uso','vontade')), CHECK((substancia_id IS NULL AND consumo IS NULL) OR (substancia_id IS NOT NULL AND consumo IS NOT NULL)));
CREATE TABLE IF NOT EXISTS metas(id INTEGER PRIMARY KEY, usuario_id INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE, titulo TEXT NOT NULL, tipo TEXT NOT NULL CHECK(tipo IN ('abstinencia','reducao','bemestar')), substancia_id INTEGER REFERENCES substancias(id), inicio TEXT NOT NULL, dias INTEGER NOT NULL CHECK(dias BETWEEN 1 AND 3650), limite INTEGER NOT NULL DEFAULT 0, atividade TEXT, CHECK((tipo='bemestar' AND substancia_id IS NULL) OR (tipo<>'bemestar' AND substancia_id IS NOT NULL)));
CREATE TABLE IF NOT EXISTS conquistas(id INTEGER PRIMARY KEY, meta_id INTEGER NOT NULL REFERENCES metas(id) ON DELETE CASCADE, ciclo TEXT NOT NULL, data TEXT NOT NULL, UNIQUE(meta_id,ciclo));
CREATE INDEX IF NOT EXISTS idx_registros ON registros(usuario_id,substancia_id,data);
CREATE INDEX IF NOT EXISTS idx_metas ON metas(usuario_id);
INSERT OR IGNORE INTO substancias(nome,categoria) VALUES ('Álcool','Cotidiano'),('Nicotina','Cotidiano'),('Cafeína','Cotidiano'),('Cannabis','Canabinoides'),('Haxixe','Canabinoides'),('Cocaína','Estimulantes'),('Crack','Estimulantes'),('Anfetamina','Estimulantes'),('Metanfetamina','Estimulantes'),('MDMA','Estimulantes'),('Metilfenidato','Medicamentos'),('Lisdexanfetamina','Medicamentos'),('Alprazolam','Sedativos'),('Clonazepam','Sedativos'),('Diazepam','Sedativos'),('Zolpidem','Sedativos'),('Pregabalina','Medicamentos'),('GHB','Sedativos'),('Codeína','Opioides'),('Tramadol','Opioides'),('Morfina','Opioides'),('Heroína','Opioides'),('Fentanil','Opioides'),('LSD','Psicodélicos'),('Psilocibina','Psicodélicos'),('DMT','Psicodélicos'),('Mescalina','Psicodélicos'),('Cetamina','Dissociativos'),('DXM','Dissociativos'),('Óxido nitroso','Dissociativos'),('Inalantes','Outros'),('Canabinoides sintéticos','Outros'),('Outra substância','Outros');

-- Diário ampliado: informações opcionais e relações um-para-muitos.
CREATE TABLE IF NOT EXISTS diario_detalhes (
    registro_id INTEGER PRIMARY KEY REFERENCES registros(id) ON DELETE CASCADE,
    sono REAL CHECK(sono BETWEEN 0 AND 24),
    energia INTEGER CHECK(energia BETWEEN 1 AND 5),
    estresse INTEGER CHECK(estresse BETWEEN 1 AND 5)
);
CREATE TABLE IF NOT EXISTS diario_atividades (
    registro_id INTEGER NOT NULL REFERENCES registros(id) ON DELETE CASCADE,
    atividade TEXT NOT NULL,
    PRIMARY KEY(registro_id, atividade)
);
CREATE TABLE IF NOT EXISTS diario_substancias (
    registro_id INTEGER NOT NULL REFERENCES registros(id) ON DELETE CASCADE,
    substancia_id INTEGER NOT NULL REFERENCES substancias(id),
    consumo TEXT NOT NULL CHECK(consumo IN ('uso','sem_uso','vontade')),
    quantidade TEXT NOT NULL DEFAULT '',
    horario TEXT NOT NULL DEFAULT '',
    contexto TEXT NOT NULL DEFAULT '',
    vontade INTEGER CHECK(vontade BETWEEN 1 AND 5),
    PRIMARY KEY(registro_id, substancia_id)
);
