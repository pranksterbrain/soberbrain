export async function api(path,method='GET',data){const r=await fetch('/api/'+path,{method,headers:{'Content-Type':'application/json'},...(data===undefined?{}:{body:JSON.stringify(data)})});const j=await r.json();if(!r.ok){if(r.status===401&&!['login','cadastro'].includes(path))location.href='/login.html';throw Error(j.erro||'Não foi possível conectar.');}return j;}
export const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export const dateLabel=s=>s?s.split('-').reverse().join('/'):'—';
export const today=()=>new Intl.DateTimeFormat('sv-SE',{timeZone:'America/Sao_Paulo',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
export function toast(s){const el=document.querySelector('#toast');if(!el)return;el.textContent=s;el.hidden=false;clearTimeout(toast.timer);toast.timer=setTimeout(()=>el.hidden=true,3800);}
export function error(el,e){el.textContent=e.message||String(e);}
export function substances(select,items,optional=false){select.innerHTML=(optional?'<option value="">Não informar</option>':'<option value="">Selecione uma substância</option>')+[...new Set(items.map(x=>x.categoria))].map(c=>`<optgroup label="${esc(c)}">${items.filter(x=>x.categoria===c).map(x=>`<option value="${x.id}">${esc(x.nome)}</option>`).join('')}</optgroup>`).join('');}
