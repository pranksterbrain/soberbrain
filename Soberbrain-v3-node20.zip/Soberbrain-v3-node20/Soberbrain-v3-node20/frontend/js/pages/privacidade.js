import {layout} from '../core/interface.js';
layout('perfil');
(async()=>{const logout=document.querySelector('#logout');const account=document.querySelector('.profile-link');try{const r=await fetch('/api/perfil');if(!r.ok)throw Error('Sem sessão');const u=await r.json();document.querySelector('#user-name').textContent=u.nome;document.querySelector('#initial').title=u.nome;}catch{logout.hidden=true;account.href='/login.html';account.setAttribute('aria-label','Entrar');account.removeAttribute('aria-current');}})();
