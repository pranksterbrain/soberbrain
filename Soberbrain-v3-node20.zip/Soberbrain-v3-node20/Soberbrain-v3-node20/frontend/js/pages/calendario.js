import {api, esc, dateLabel, today, error} from '../core/api.js';
import {layout, profile, moodNames, react} from '../core/interface.js';

/* 1. Estado e datas */
layout('calendario');
const $ = selector => document.querySelector(selector);
const key = (y,m,d) => `${y}-${String(m+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
let records = [], selected = today(), current = new Date(today()+'T12:00:00');
current.setDate(1);
const consumption = {uso:'Uso',sem_uso:'Sem uso',vontade:'Vontade'};
const validMood = r => Number.isInteger(r.humor) && r.humor>=1 && r.humor<=5;
const substances = r => r.substancias ?? (r.substancia_id?[r]:[]);
const activities = r => r.atividades ?? (r.atividade?[r.atividade]:[]);

/* 2. Registros do dia */
function drawDay(){
    $('#day-title').textContent='Registros · '+dateLabel(selected);
    const day=records.filter(r=>r.data===selected);
    $('#day-records').innerHTML=day.length?day.map(r=>`<article class="record">
        <div class="record-heading">${validMood(r)?`<img class="record-mood" src="/assets/icons/mood-${r.humor}.png" alt=""><strong>${esc(moodNames[r.humor-1])}</strong>`:'<strong>Registro do dia</strong>'}</div>
        ${substances(r).map(s=>`<p><strong>${esc(s.substancia)}</strong> · ${esc(consumption[s.consumo])}${s.quantidade?' · '+esc(s.quantidade):''}${s.horario?' · '+esc(s.horario):''}${s.contexto?' · '+esc(s.contexto):''}${s.vontade?' · Vontade: '+esc(s.vontade)+'/5':''}</p>`).join('')}
        ${activities(r).length?`<p>${esc(activities(r).join(' · '))}</p>`:''}
        <p>${esc([r.sono!=null?`Sono: ${r.sono} h`:null,r.energia!=null?`Energia: ${r.energia}/5`:null,r.estresse!=null?`Estresse: ${r.estresse}/5`:null].filter(Boolean).join(' · '))}</p>
        ${r.nota?`<p>${esc(r.nota)}</p>`:''}</article>`).join(''):'<p class="notice">Não há registros neste dia.</p>';
}

/* 3. Calendário e legenda */
function drawCalendar(monthRecords){
    const y=current.getFullYear(),m=current.getMonth(),first=new Date(y,m,1).getDay(),last=new Date(y,m+1,0).getDate();
    $('#month').textContent=current.toLocaleDateString('pt-BR',{month:'long',year:'numeric'});
    const blank=()=>'<button class="day" disabled aria-hidden="true"></button>';
    $('#calendar').innerHTML=['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'].map(d=>`<small>${d}</small>`).join('')+Array.from({length:first},blank).join('')+Array.from({length:last},(_,i)=>{
        const d=key(y,m,i+1), day=monthRecords.filter(r=>r.data===d), n=day.length;
        const mood=day.filter(validMood).sort((a,b)=>b.id-a.id)[0]?.humor;
        const description=`${dateLabel(d)}, ${n} registro(s), ${mood?moodNames[mood-1]:'Sem humor registrado'}`;
        return `<button class="day ${n?'active':''} ${d===selected?'mark':''} ${d===today()?'is-today':''}" data-day="${d}" ${mood?`data-mood="${mood}"`:''} aria-pressed="${d===selected}" aria-label="${esc(description)}" title="${esc(description)}"><span class="day-number">${i+1}</span>${mood?`<img class="calendar-mood" src="/assets/icons/mood-${mood}.png" alt="" width="30" height="30">`:''}${n?`<small>${n} reg.</small>`:''}</button>`;
    }).join('')+Array.from({length:(7-(first+last)%7)%7},blank).join('');
    $('#calendar').querySelectorAll('[data-day]').forEach(b=>b.onclick=()=>{selected=b.dataset.day;draw();$('#calendar').querySelector(`[data-day="${selected}"]`)?.focus({preventScroll:true});react();});
}
function drawLegend(){
    const legend=$('#calendar + .notice'); if(!legend)return;
    legend.classList.add('calendar-legend');
    legend.innerHTML=moodNames.map((name,i)=>`<span class="legend-item" data-mood="${i+1}"><span class="legend-color"></span>${esc(name)}</span>`).join('')+'<span class="legend-item"><span class="legend-color"></span>Sem humor registrado</span>';
}

/* 4. Estatísticas: uma emoção por registro, dias distintos por substância */
function drawCharts(rows){
    const valid=rows.filter(validMood);
    $('#mood-chart').innerHTML=moodNames.map((name,i)=>{const count=valid.filter(r=>r.humor===i+1).length;return `<div class="chart-row"><span>${esc(name)}</span><progress max="${Math.max(1,valid.length)}" value="${count}" aria-label="${esc(name)}"></progress><span>${count}</span></div>`;}).join('');
    const counts=new Map();
    for(const r of rows) for(const s of substances(r)) if(s.consumo==='uso'&&s.substancia){if(!counts.has(s.substancia))counts.set(s.substancia,new Set());counts.get(s.substancia).add(r.data);}
    $('#use-chart').innerHTML=counts.size?[...counts].map(([name,days])=>`<div class="spread"><span>${esc(name)}</span><strong>${days.size} ${days.size===1?'dia':'dias'}</strong></div>`).join(''):'<p class="notice">Nenhum consumo relatado neste mês.</p>';
}
function draw(){const prefix=key(current.getFullYear(),current.getMonth(),1).slice(0,7), rows=records.filter(r=>r.data.startsWith(prefix));drawCalendar(rows);drawCharts(rows);drawDay();}
function changeMonth(direction){current.setMonth(current.getMonth()+direction);selected=key(current.getFullYear(),current.getMonth(),1);draw();}
$('#prev').onclick=()=>changeMonth(-1);
$('#next').onclick=()=>changeMonth(1);
(async()=>{try{await profile();records=await api('registros');drawLegend();draw();}catch(e){error($('#error'),e);}})();
