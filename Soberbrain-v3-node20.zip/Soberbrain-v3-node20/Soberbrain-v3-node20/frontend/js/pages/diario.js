import { api, esc, dateLabel, today, error, toast } from '../core/api.js';
import { layout, profile, moodButtons, moodNames, react, icon } from '../core/interface.js';

/* 1. Estado e opções */
layout('diario');
const $ = selector => document.querySelector(selector);
const form = $('#record-form');
const f = form.elements;
const params = new URLSearchParams(location.search);
let mood = null, edit = null, records = [], catalog = [], saving = false;
const consumption = {uso:'Consumi', sem_uso:'Não consumi', vontade:'Senti vontade'};
const groups = {
    'Rotina e saúde': ['Exercício','Estudo','Trabalho','Descanso','Sono','Alimentação','Autocuidado','Terapia','Meditação'],
    'Lazer e convivência': ['Lazer','Leitura','Música','Social','Família','Amigos','Comemoração'],
    'Situações e sentimentos': ['Ansiedade','Conflito','Solidão','Tédio','Estresse','Dor']
};
const level = value => value === '' ? null : Number(value);
const normalize = value => value.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
const options = (selected, labels) => '<option value="">Não informar</option>' + labels.map((label,i) => `<option value="${i+1}" ${Number(selected)===i+1?'selected':''}>${label}</option>`).join('');
f.data.max = today(); f.data.value = today();

/* 2. Humor e atividades */
function setMood(value) {
    mood = value;
    moodButtons($('#moods'),mood,v => {
        setMood(mood===v?null:v);
        $('#moods').querySelector(`[data-mood="${v}"]`)?.focus({preventScroll:true});
        react();
    });
}
$('#activities').innerHTML = Object.entries(groups).map(([title,items]) => `
    <div class="activity-group"><h3>${esc(title)}</h3><div class="activity-options">
        ${items.map(a => `<label class="activity-chip"><input type="checkbox" name="atividades" value="${esc(a)}"><span>${esc(a)}</span></label>`).join('')}
    </div></div>`).join('');
const activities = () => [...$('#activities').querySelectorAll('input:checked')].map(el => el.value);
function counts() {
    const n = $('#substance-list').children.length, a = activities().length;
    $('#substance-count').textContent = n ? `${n} substância(s) adicionada(s).` : 'Nenhuma substância adicionada.';
    $('#activity-count').textContent = a ? `${a} opção(ões) selecionada(s).` : 'Nenhuma opção selecionada.';
    $('#note-count').textContent = `${f.nota.value.length} / 2000`;
}
$('#activities').addEventListener('change',counts);
f.nota.addEventListener('input',counts);

/* 3. Catálogo e seleção múltipla */
function updatePicker() {
    const select = $('#substance-select'), previous = select.value;
    const used = new Set([...$('#substance-list').children].map(el => Number(el.dataset.sid)));
    const query = normalize($('#substance-search').value.trim());
    const filtered = catalog.filter(s => !used.has(s.id) && normalize(s.nome+' '+s.categoria).includes(query));
    select.innerHTML = `<option value="">${filtered.length?'Escolha uma substância':'Nenhuma opção disponível'}</option>` + [...new Set(filtered.map(s=>s.categoria))].map(c => `<optgroup label="${esc(c)}">${filtered.filter(s=>s.categoria===c).map(s=>`<option value="${s.id}">${esc(s.nome)}</option>`).join('')}</optgroup>`).join('');
    if (filtered.some(s => String(s.id)===previous)) select.value=previous;
    $('#add-substance').disabled = !select.value;
    counts();
}
$('#substance-search').addEventListener('input',updatePicker);
$('#substance-select').addEventListener('change',()=>$('#add-substance').disabled=!$('#substance-select').value);
$('#add-substance').addEventListener('click',()=>{
    const id = Number($('#substance-select').value);
    if (id) { addSubstance({substancia_id:id}); $('#substance-search').value=''; updatePicker(); }
});
function addSubstance(data) {
    const item = catalog.find(s=>s.id===Number(data.substancia_id));
    if (!item || $('#substance-list').querySelector(`[data-sid="${item.id}"]`)) return;
    const id = item.id;
    const card = document.createElement('section');
    card.className='substance-card'; card.dataset.sid=id;
    card.innerHTML=`
        <div class="spread"><div><small>${esc(item.categoria)}</small><h3>${esc(item.nome)}</h3></div><button type="button" class="icon-btn remove-substance" aria-label="Remover ${esc(item.nome)}">${icon('close')}</button></div>
        <div class="stack"><span class="notice">O que aconteceu?</span><div class="status-choices" role="group" aria-label="Situação de ${esc(item.nome)}">
            ${Object.entries(consumption).map(([value,label])=>`<label class="status-choice"><input type="radio" name="consumo-${id}" value="${value}" ${data.consumo===value?'checked':''} required><span>${label}</span></label>`).join('')}
        </div></div>
        <details class="diary-details" ${data.quantidade||data.horario||data.contexto||data.vontade?'open':''}>
            <summary>Detalhes opcionais</summary>
            <div class="diary-fields">
                <label class="use-only">Quantidade relatada<input data-field="quantidade" maxlength="60" value="${esc(data.quantidade)}" placeholder="Se quiser, quantidade e unidade"></label>
                <label class="use-only">Horário aproximado<input type="time" data-field="horario" value="${esc(data.horario)}"></label>
                <label>Intensidade da vontade<select data-field="vontade">${options(data.vontade,['Muito baixa','Baixa','Moderada','Alta','Muito alta'])}</select></label>
                <label class="wide">Contexto ou gatilho<input data-field="contexto" maxlength="160" value="${esc(data.contexto)}" placeholder="O que estava acontecendo?"></label>
            </div>
        </details>`;
    const visibility=()=>{const use=card.querySelector('input:checked')?.value==='uso';card.querySelectorAll('.use-only').forEach(el=>{el.hidden=!use;el.querySelector('input').disabled=!use;});};
    card.addEventListener('change',visibility);
    card.querySelector('.remove-substance').addEventListener('click',()=>{card.remove();updatePicker();$('#substance-select').focus();});
    $('#substance-list').append(card); visibility(); updatePicker();
}
function readSubstances() {
    return [...$('#substance-list').children].map(card=>{
        const get = key=>card.querySelector(`[data-field="${key}"]`).value;
        const consumo = card.querySelector('input[type="radio"]:checked')?.value;
        return {substancia_id:Number(card.dataset.sid),consumo,quantidade:consumo==='uso'?get('quantidade'):'',horario:consumo==='uso'?get('horario'):'',contexto:get('contexto'),vontade:level(get('vontade'))};
    });
}

/* 4. Histórico, edição e exclusão */
function reset() {
    edit=null; form.reset(); f.data.value=today(); setMood(null);
    $('#substance-list').replaceChildren(); $('#substance-search').value=''; $('#wellbeing').open=false;
    $('#record-title').textContent='Novo registro'; $('#cancel-edit').hidden=true; $('#error').textContent=''; updatePicker();
}
$('#cancel-edit').onclick=reset;
function editRecord(r) {
    reset(); edit=r.id; f.data.value=r.data; setMood(r.humor);
    for(const key of ['sono','energia','estresse','nota']) f[key].value=r[key]??'';
    $('#wellbeing').open=[r.sono,r.energia,r.estresse].some(v=>v!=null);
    $('#activities').querySelectorAll('input').forEach(el=>el.checked=(r.atividades||[]).includes(el.value));
    (r.substancias||[]).forEach(addSubstance);
    $('#record-title').textContent='Editar registro'; $('#cancel-edit').hidden=false; counts();
    $('#record-title').scrollIntoView({block:'start'}); f.data.focus({preventScroll:true});
}
function renderHistory() {
    const date=$('#history-date').value;
    const filtered=records.filter(r=>!date||r.data===date);
    $('#history-count').textContent=filtered.length; $('#clear-filter').hidden=!date;
    $('#records').innerHTML=filtered.length?filtered.map(r=>`
        <article class="record">
            <div class="spread"><strong>${esc(dateLabel(r.data))}</strong><div class="row"><button class="icon-btn" data-edit="${r.id}" aria-label="Editar registro">${icon('edit')}</button><button class="icon-btn" data-delete="${r.id}" aria-label="Excluir registro">${icon('trash')}</button></div></div>
            ${r.humor?`<div class="record-mood"><img src="/assets/icons/mood-${r.humor}.png" alt=""><strong>${esc(moodNames[r.humor-1])}</strong></div>`:''}
            ${r.substancias.map(s=>`<div><p><strong>${esc(s.substancia)}</strong> · ${esc(consumption[s.consumo])}</p>${[s.quantidade,s.horario,s.contexto,s.vontade?`Vontade: ${s.vontade}/5`:null].filter(Boolean).length?`<p class="notice">${esc([s.quantidade,s.horario,s.contexto,s.vontade?`Vontade: ${s.vontade}/5`:null].filter(Boolean).join(' · '))}</p>`:''}</div>`).join('')}
            <div class="diary-tags">${r.atividades.map(a=>`<span class="diary-tag">${esc(a)}</span>`).join('')}</div>
            <p class="notice">${esc([r.sono!=null?`Sono: ${r.sono} h`:null,r.energia!=null?`Energia: ${r.energia}/5`:null,r.estresse!=null?`Estresse: ${r.estresse}/5`:null].filter(Boolean).join(' · '))}</p>
            ${r.nota?`<p>${esc(r.nota)}</p>`:''}
        </article>`).join(''):'<p class="notice">Nenhum registro encontrado.</p>';
}
async function load() { records=await api('registros'); renderHistory(); }
$('#history-date').onchange=renderHistory;
$('#clear-filter').onclick=()=>{$('#history-date').value='';renderHistory();};
$('#records').onclick=async event=>{
    const b=event.target.closest('button'); if(!b||saving)return;
    if(b.dataset.edit){const r=records.find(r=>r.id===Number(b.dataset.edit));if(r)editRecord(r);}
    if(b.dataset.delete&&confirm('Excluir este registro? O progresso atual das metas será recalculado.')){
        saving=true;
        try{await api('registros/'+b.dataset.delete,'DELETE');if(edit===Number(b.dataset.delete))reset();await load();react('Registro excluído.');}catch(e){toast(e.message);}finally{saving=false;}
    }
};

/* 5. Salvamento e integração */
form.onsubmit=async event=>{
    event.preventDefault(); if(saving)return;
    $('#error').textContent='';
    const data={data:f.data.value,humor:mood,atividades:activities(),substancias:readSubstances(),sono:level(f.sono.value),energia:level(f.energia.value),estresse:level(f.estresse.value),nota:f.nota.value};
    if(!data.humor&&!data.atividades.length&&!data.substancias.length&&data.sono===null&&data.energia===null&&data.estresse===null&&!data.nota.trim()){error($('#error'),new Error('Preencha ao menos uma informação.'));return;}
    saving=true;$('#save-record').disabled=true;
    try{await api(edit?'registros/'+edit:'registros',edit?'PUT':'POST',data);reset();react('Registro salvo. Suas metas serão atualizadas.');try{await load();}catch(e){toast('Registro salvo; não foi possível atualizar o histórico.');}}catch(e){error($('#error'),e);}finally{saving=false;$('#save-record').disabled=false;}
};
async function initialize(){
    try{await profile();catalog=await api('substancias');const initial=Number(params.get('humor'));setMood(initial>=1&&initial<=5?initial:null);updatePicker();const sid=Number(params.get('substancia'));if(sid)addSubstance({substancia_id:sid});await load();$('#save-record').disabled=false;}
    catch(e){error($('#error'),e);}
}
setMood(null);counts();initialize();
