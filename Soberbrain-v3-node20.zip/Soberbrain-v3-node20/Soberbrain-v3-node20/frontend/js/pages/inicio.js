import {renderFooter} from '../core/interface.js';
renderFooter();
const q=document.querySelector('#questionnaire'), open=document.querySelector('#questions');
open.onclick=()=>{q.hidden=false;open.setAttribute('aria-expanded','true');q.querySelector('input').focus();};
document.querySelector('#skip').onclick=()=>{q.hidden=true;open.setAttribute('aria-expanded','false');open.focus();};
document.querySelector('#welcome-form').onsubmit=e=>{e.preventDefault();const v=new FormData(e.currentTarget).get('interest');location.href=v==='metas'?'/pages/metas.html':'/pages/diario.html';};
const labels=['Entenda melhor a si mesmo','Acompanhe sua evolução dia após dia','Perceba o que vem antes da vontade de consumir','Seu espaço, suas escolhas','Um dia difícil não apaga seu progresso'];
document.querySelector('#benefits').innerHTML=labels.map((label,i)=>`<article class="benefit"><img src="/assets/icons/benefit-${i+1}.png" alt=""><p>${label}</p></article>`).join('');
